var gis = require('chalk');

console.log(gis.greenBright("Hola mundo"));
